
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Mock database and state
  let datasets = [
    { 
      id: 'ds_1', 
      name: 'Commoner_Greetings', 
      versions: [
        { tag: 'v1.0.0', size: '2.4MB', entries: 1200, createdAt: new Date(Date.now() - 86400000).toISOString() },
        { tag: 'v1.1.0', size: '2.8MB', entries: 1450, createdAt: new Date().toISOString() },
      ]
    },
    { 
      id: 'ds_2', 
      name: 'Guard_Banter', 
      versions: [
        { tag: 'v0.9.0', size: '1.2MB', entries: 800, createdAt: new Date(Date.now() - 172800000).toISOString() },
      ]
    }
  ];

  let jobs = [
    { 
      id: '1', 
      name: 'QuestGiver_LoRA_v1', 
      status: 'completed', 
      progress: 100, 
      loss: 0.12, 
      type: 'Training', 
      createdAt: new Date(Date.now() - 3600000).toISOString(),
      stages: [
        { name: 'Dataset Prep', status: 'completed', logs: ['Validated 1450 pairs', 'Deduplication success'] },
        { name: 'Hyperparam Tuning', status: 'completed', logs: ['Rank=16 selected', 'Alpha=32 optimized'] },
        { name: 'Training', status: 'completed', logs: ['Epoch 4/4 safe', 'Checkpoint saved'] },
        { name: 'Evaluation', status: 'completed', logs: ['BLEU: 0.82', 'Perplexity: 1.4'] },
      ]
    },
    { 
      id: '2', 
      name: 'Blacksmith_Dialogue_Gen', 
      status: 'running', 
      progress: 45, 
      loss: null, 
      type: 'Dataset Gen', 
      createdAt: new Date().toISOString(),
      stages: [
        { name: 'Dataset Prep', status: 'running', logs: ['Generating samples via LLM...', '450/1000 complete'] },
        { name: 'Hyperparam Tuning', status: 'pending', logs: [] },
        { name: 'Training', status: 'pending', logs: [] },
        { name: 'Evaluation', status: 'pending', logs: [] },
      ]
    },
  ];

  let logs: string[] = [
    "[INFO] Initializing training environment...",
    "[INFO] Loading base model: Mistral-7B-Instruct-v0.2",
    "[INFO] Found 1450 dialogue pairs in dataset.",
    "[DEBUG] Optimizer set to AdamW with lr=2e-4",
  ];

  // API Routes
  app.get("/api/jobs", (req, res) => {
    res.json(jobs);
  });

  app.get("/api/analytics", (req, res) => {
    const historicalData = [
      { step: 100, loss: 1.2, acc: 0.45, lr: 2e-4 },
      { step: 200, loss: 0.8, acc: 0.65, lr: 2e-4 },
      { step: 300, loss: 0.5, acc: 0.78, lr: 1.5e-4 },
      { step: 400, loss: 0.3, acc: 0.85, lr: 1e-4 },
      { step: 500, loss: 0.15, acc: 0.92, lr: 5e-5 },
    ];
    res.json(historicalData);
  });

  app.get("/api/available-commands", (req, res) => {
    res.json([
      { id: 'cmd_1', label: 'Clear VRAM Cache', icon: 'zap', color: 'accent' },
      { id: 'cmd_2', label: 'Export ONNX Weights', icon: 'external-link', color: 'success' },
      { id: 'cmd_3', label: 'Rebuild Unity Bridge', icon: 'layers', color: 'warning' },
      { id: 'cmd_4', label: 'Kill Zombie PIDs', icon: 'x-circle', color: 'danger' },
      { id: 'cmd_5', label: 'Prune Orphaned Logs', icon: 'database', color: 'default' },
    ]);
  });

  app.get("/api/datasets", (req, res) => {
    res.json(datasets);
  });

  // Simulate progress
  setInterval(() => {
    jobs = jobs.map(job => {
      if (job.status === 'running') {
        const newProgress = Math.min(100, job.progress + Math.floor(Math.random() * 5));
        
        // Update stages based on progress
        const updatedStages = job.stages.map((stage, idx) => {
          const threshold = (idx + 1) * 25;
          if (newProgress >= threshold) return { ...stage, status: 'completed' };
          if (newProgress > idx * 25) return { ...stage, status: 'running' };
          return stage;
        });

        return { 
          ...job, 
          progress: newProgress,
          status: newProgress === 100 ? 'completed' : 'running',
          loss: job.type === 'Training' ? Math.max(0.01, (job.loss || 1.0) * 0.98) : null,
          stages: updatedStages
        };
      }
      return job;
    });
  }, 5000);

  app.get("/api/logs", (req, res) => {
    res.json(logs);
  });

  app.post("/api/commands/start", (req, res) => {
    const { name, type } = req.body;
    const newJob = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      status: 'pending',
      progress: 0,
      loss: null,
      type: type || 'Training',
      createdAt: new Date().toISOString(),
      stages: [
        { name: 'Dataset Prep', status: 'pending', logs: [] },
        { name: 'Hyperparam Tuning', status: 'pending', logs: [] },
        { name: 'Training', status: 'pending', logs: [] },
        { name: 'Evaluation', status: 'pending', logs: [] },
      ]
    };
    if (newJob.type === 'Training') {
        newJob.status = 'running'; // Auto-start for demo
        newJob.stages[0].status = 'running';
    }
    jobs.unshift(newJob);
    logs.push(`[SYSTEM] Triggered ${type} job: ${name}`);
    res.json(newJob);
  });

  app.post("/api/commands/stop", (req, res) => {
    const { id } = req.body;
    jobs = jobs.map(j => j.id === id ? { ...j, status: 'stopped' } : j);
    logs.push(`[SYSTEM] Stopped job ${id}`);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
